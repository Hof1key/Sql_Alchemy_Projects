import sqlalchemy
import datetime
from flask_login import UserMixin, LoginManager, login_user
from flask_wtf import FlaskForm
from werkzeug.utils import redirect
from wtforms import *
from wtforms.validators import DataRequired

from stt.data import db_session
from flask import Flask, render_template

from stt.data.db_session import SqlAlchemyBase
from stt.data.users import User

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

login_manager = LoginManager()
login_manager.init_app(app)

'''m = [['Scott', 'Ridley', 21, 'captain', 'research engineer', 'module_1', 'scott_chief@mars.org'],
     ['Harley', 'Basic', 34, 'enginer', 'building engineer', 'module_5', 'harley_b@mars.org'],
     ['Johny', 'Graph', 20, 'programmer', 'main coder', 'module_2', 'johny_tt@mars.org'],
     ['Joseph', 'Trey', 55, 'mechanic', 'architector', 'module_3', 'im_joseph@mars.org']]

j = [[1, 'deployment of residential modules 1 and 2', 15, '2, 3', False]]


class User(SqlAlchemyBase, UserMixin):
    __tablename__ = 'users'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    surname = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    name = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    age = sqlalchemy.Column(sqlalchemy.Integer, nullable=True)
    position = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    speciality = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    address = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    email = sqlalchemy.Column(sqlalchemy.String,
                              index=True, unique=True, nullable=True)
    hashed_password = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    modified_date = sqlalchemy.Column(sqlalchemy.DateTime,
                                      nullable=True)


def main_f():
    db_session.global_init("db/blogs.db")

    db_sess = db_session.create_session()
    for user in m:
        user_i = User()
        user.surname = user[0]
        user.name = user[1]
        user.age = user[2]
        user.position = user[3]
        user.speciality = user[4]
        user.address = user[5]
        user.email = user[6]
        user.hashed_password = user[7]
        db_sess.add(user_i)
        db_sess.commit()

main_f()'''

@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)


class LoginForm(FlaskForm):
    email = EmailField('Почта', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    remember_me = BooleanField('Запомнить меня')
    submit = SubmitField('Войти')


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/')
@app.route('/index')
def index():
    return "Привет, Яндекс!"


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')